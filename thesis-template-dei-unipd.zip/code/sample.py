# This is a sample code

def hello_world():
    return 'Hello, World!'


def main():
    print(hello_world())


if __name__=='__main__':
    main()
